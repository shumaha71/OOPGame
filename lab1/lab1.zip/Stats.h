#pragma once

class Stats {
public:
    int health, armor, attack;
    Stats(int h, int a, int atk) : health(h), armor(a), attack(atk) {}
};
